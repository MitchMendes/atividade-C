/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>

int main() {
    int altCam, largCam, compCam;
    int altCx, largCx, compCx;
    int total;

    printf("Digite altura, largura e comprimento do caminhao: ");
    scanf("%d %d %d", &altCam, &largCam, &compCam);

    printf("Digite altura, largura e comprimento da caixa: ");
    scanf("%d %d %d", &altCx, &largCx, &compCx);

    total = (altCam / altCx) * (largCam / largCx) * (compCam / compCx);

    printf("Quantidade de caixas: %d\n", total);

    return 0;
}
