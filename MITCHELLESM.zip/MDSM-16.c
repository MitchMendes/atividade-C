/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n; printf("Digite o numero do pedido: "); scanf("%d",&n);
if(n%3==0 && n%5==0) printf("Ganhou refrigerante e sobremesa\n");
else if(n%3==0) printf("Ganhou refrigerante\n");
else if(n%5==0) printf("Ganhou sobremesa\n");
else printf("Nao ganhou premio\n");
return 0;}
