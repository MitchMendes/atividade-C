/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int altura; printf("Digite a altura em cm: "); scanf("%d",&altura);
if(altura>=140) printf("Liberado\n"); else printf("Barrado\n");
return 0;}
