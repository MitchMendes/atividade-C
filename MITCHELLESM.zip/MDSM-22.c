/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n;
printf("Digite um numero: "); scanf("%d",&n);
if(n%2==0) printf("Par\n");
else printf("Impar\n");
return 0;}
