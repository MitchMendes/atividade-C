/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){float a,b;
printf("Digite dois numeros: "); scanf("%f %f",&a,&b);
if(a>b) printf("Maior: %.2f\n",a);
else printf("Maior: %.2f\n",b);
return 0;}
