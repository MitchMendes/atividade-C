/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int i; for(i=1;i<=10;i++) printf("%d\n",i); return 0;}
