/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n,i; printf("Digite um numero: "); scanf("%d",&n);
for(i=1;i<=10;i++) printf("%d x %d = %d\n",n,i,n*i);
return 0;}
