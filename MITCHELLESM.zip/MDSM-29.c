/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int i;
for(i=0;i<=50;i+=2) printf("%d\n",i);
return 0;}
