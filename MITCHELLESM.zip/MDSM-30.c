/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n,i,f=1;
printf("Digite um numero: "); scanf("%d",&n);
for(i=1;i<=n;i++) f*=i;
printf("Fatorial = %d\n",f);
return 0;}
