/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int i;
for(i=10;i>=1;i--) printf("%d\n",i);
return 0;}
