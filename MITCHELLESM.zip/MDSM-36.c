/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int i=1; while(i<=10){printf("%d\n",i); i++;} return 0;}
