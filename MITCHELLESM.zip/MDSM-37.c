/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n,soma=0;
do{printf("Digite um numero (0 para sair): "); scanf("%d",&n); soma+=n;}while(n!=0);
printf("Soma = %d\n",soma); return 0;}
