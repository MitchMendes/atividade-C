/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int senha;
while(senha!=1234){printf("Digite a senha: "); scanf("%d",&senha);}
printf("Acesso permitido\n"); return 0;}
