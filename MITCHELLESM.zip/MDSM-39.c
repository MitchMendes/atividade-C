/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n=0;
while(n<=0){printf("Digite um numero positivo: "); scanf("%d",&n);}
printf("Numero valido\n"); return 0;}
