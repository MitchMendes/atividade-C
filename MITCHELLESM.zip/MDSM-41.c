/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n,i=2,primo=1;
printf("Digite um numero: "); scanf("%d",&n);
while(i<n){if(n%i==0) primo=0; i++;}
if(primo && n>1) printf("Primo\n"); else printf("Nao primo\n");
return 0;}
