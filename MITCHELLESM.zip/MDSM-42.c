/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n,i=1,cont=0;
while(i<=10){printf("Digite um numero: "); scanf("%d",&n); if(n%2!=0) cont++; i++;}
printf("Quantidade de impares: %d\n",cont);
return 0;}
