/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n,cont=0;
printf("Digite um numero positivo: "); scanf("%d",&n);
while(n>0){cont++; n/=10;}
printf("Quantidade de digitos: %d\n",cont);
return 0;}
