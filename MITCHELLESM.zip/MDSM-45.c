/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int op=0;
while(op!=3){
printf("1-Saque\n2-Saldo\n3-Sair\n");
scanf("%d",&op);
}
return 0;}
