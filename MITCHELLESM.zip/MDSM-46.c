/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int i=1;
do{printf("%d\n",i); i++;}while(i<=10);
return 0;}
