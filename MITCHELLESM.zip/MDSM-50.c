/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n;
do{printf("Digite um numero positivo: "); scanf("%d",&n);}while(n<=0);
printf("Numero aceito\n");
return 0;}
