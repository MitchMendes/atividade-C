/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int i=10;
do{printf("%d\n",i); i--;}while(i>=1);
return 0;}
