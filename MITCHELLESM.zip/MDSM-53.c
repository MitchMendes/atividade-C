/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){char op;
do{
printf("Executando menu...\n");
printf("Deseja sair? (s/n): ");
scanf(" %c",&op);
}while(op!='s');
return 0;}
