/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n;
do{printf("Digite um numero entre 1 e 5: "); scanf("%d",&n);}while(n<1 || n>5);
printf("Numero valido\n");
return 0;}
