/*
Aluno: MITCHELLE DA SILVA MENDES
RA: 0026471
*/

#include <stdio.h>
int main(){int n,maior=0;
do{
printf("Digite um numero: ");
scanf("%d",&n);
if(n>maior) maior=n;
}while(n>=0);
printf("Maior numero: %d\n",maior);
return 0;}
